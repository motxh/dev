# Heels Plugin
This is a plugin to be used with the [FFXIVQuickLauncher](https://github.com/goatcorp/FFXIVQuickLauncher).

## Installing
Please visit [this](https://github.com/LeonBlade/DalamudPlugins) for instructions on how to install the plugin.

## Usage
To use the plugin, you must have launched the game via FFXIVQuickLauncher.
Then, all you need to do is type `/xlheels` in the in game chat to show the config menu. Add your configs for the various mods you have installed with the offsets you need and when you equip those items the offsets will be applied.

## Notes
Due to the nature of this plugin and how it works, you will float off of the ground even while sitting. This plugin also
hasn't been tested extensively, so there may be some issues. Please contact me if you run into any major problems.

## Donations
**Ko-Fi:** https://ko-fi.com/LeonBlade

**Patreon:** https://patreon.com/LeonBlade
